# Symbol Keyboard

Build a keyboard of Unicode symbols and emoji and type them directly into the web page you’re editing.

## Install in Chrome

1. Extract the ZIP to a folder you can keep.
2. Open `chrome://extensions`.
3. Turn on **Developer mode** and click **Load unpacked**.
4. Select the extracted **extension** folder, which contains `manifest.json`.
5. Open Chrome’s Extensions menu and pin **Symbol Keyboard**.

## Use it

1. Open a regular web page and click the toolbar icon.
2. Choose **Edit keys** and select a specific key. Pick a symbol from the library or enter one custom symbol. Pick the next key to continue.
3. Choose **Done**. Click into a field and press a symbol key to insert it at the cursor or replace highlighted text. The panel stays open while you type.

Select an occupied key in edit mode to replace its symbol or **Clear key**. Chrome saves the layout locally and shares it across tabs in the same profile. The toolbar button toggles the keyboard. You can also use **Alt+Shift+Y** if Chrome assigns that shortcut. Manage shortcuts at `chrome://extensions/shortcuts`.

The extension supports ordinary text fields, text areas, and basic contenteditable editors in the main page. Chrome system pages, password fields, and editors running in separate frames or using custom canvas-based input are outside this version’s support. The extension requests access to the active tab when you open it.

## Build from source

The included `extension` folder is already built. To rebuild it with Node.js 22 or newer, run `npm ci` and `npm run build` from this directory, then reload the extension in Chrome.
