import {build} from 'esbuild';

await build({
  entryPoints: ['src/keyboard.jsx'],
  outfile: 'extension/keyboard.js',
  bundle: true,
  minify: true,
  loader: {'.css': 'text'},
  define: {'process.env.NODE_ENV': '"production"'},
  legalComments: 'eof',
  target: 'chrome120',
});
