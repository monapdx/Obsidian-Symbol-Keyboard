chrome.action.onClicked.addListener(async ({id}) => {
  if (id === undefined) return;
  try {
    await chrome.scripting.executeScript({target: {tabId: id}, files: ['keyboard.js']});
    await chrome.action.setBadgeText({tabId: id, text: ''});
  } catch {
    await chrome.action.setBadgeText({tabId: id, text: '×'});
    await chrome.action.setTitle({tabId: id, title: 'Symbol Keyboard is unavailable on this page'});
    return;
  }
  await chrome.action.setTitle({tabId: id, title: 'Toggle Symbol Keyboard'});
});
