import React, {useEffect, useState} from 'react';
import {createRoot} from 'react-dom/client';
import {catalog, categories} from './catalog';
import {createTypingTarget} from './typing';
import styles from './panel.css';

const rows = [10, 9, 8, 7];
const total = rows.reduce((sum, count) => sum + count, 0);
const storagePrefix = 'symbol-key-';
const graphemes = new Intl.Segmenter(undefined, {granularity: 'grapheme'});

function Keyboard({close, typing}) {
  const [layout, setLayout] = useState({});
  const [ready, setReady] = useState(false);
  const [editing, setEditing] = useState(false);
  const [selected, setSelected] = useState(null);
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('All symbols');
  const [custom, setCustom] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let active = true;
    function update(changes, area) {
      if (area !== 'local') return;
      setLayout(previous => {
        const next = {...previous};
        for (const [key, change] of Object.entries(changes)) {
          if (key.startsWith(storagePrefix)) next[key] = change.newValue;
        }
        return next;
      });
    }
    chrome.storage.onChanged.addListener(update);
    chrome.storage.local.get(null).then(saved => {
      if (!active) return;
      setLayout(saved);
      setReady(true);
    }).catch(() => active && setMessage('Could not load your keys. Reload the page to retry.'));
    return () => {
      active = false;
      chrome.storage.onChanged.removeListener(update);
    };
  }, []);

  const assigned = index => layout[storagePrefix + index];
  const filled = Array.from({length: total}, (_, index) => assigned(index)).filter(Boolean).length;
  const words = query.toLowerCase().trim().split(/\s+/);
  const found = catalog.filter(({name, symbol, category: group}) =>
    (category === 'All symbols' || group === category) &&
    words.every(word => (name + ' ' + symbol + ' ' + group.toLowerCase()).includes(word))
  );

  async function assign(item) {
    if (selected === null || busy) return;
    setBusy(true);
    const key = storagePrefix + selected;
    try {
      if (item) await chrome.storage.local.set({[key]: item});
      else await chrome.storage.local.remove(key);
      setMessage(item ? `Assigned ${item.symbol} to key ${selected + 1}.` : `Cleared key ${selected + 1}.`);
      setSelected(null);
      setCustom('');
    } catch {
      setMessage('Could not save the key. Try again.');
    } finally {
      setBusy(false);
    }
  }

  function press(index, item) {
    setMessage('');
    if (editing) {
      if (!busy) setSelected(index);
      return;
    }
    if (item) setMessage(typing.insert(item.symbol)
      ? `Inserted ${item.symbol}.`
      : 'Click a text field on this page with room for the symbol, then try again.');
  }

  function addCustom(event) {
    event.preventDefault();
    const symbol = custom.trim();
    if (!symbol || [...graphemes.segment(symbol)].length !== 1) {
      setMessage('Enter one symbol or emoji.');
      return;
    }
    void assign({symbol, name: 'Custom symbol'});
  }

  let index = 0;
  return (
    <section className="panel" aria-label="Symbol Keyboard" onKeyDown={event => {
      if (event.key === 'Escape') {
        event.stopPropagation();
        close();
      }
    }}>
      <header>
        <span className="brand-icon" aria-hidden="true">⌘</span>
        <div className="heading">
          <h1>Symbol Keyboard</h1>
          <p>{filled} of {total} keys assigned</p>
        </div>
        <button className="mode" disabled={!ready || busy} onClick={() => {
          setEditing(!editing);
          setSelected(null);
          setMessage('');
        }}>{editing ? 'Done' : 'Edit keys'}</button>
        <button className="close" aria-label="Close Symbol Keyboard" onClick={close}>×</button>
      </header>
      <div className="keyboard" aria-label={editing ? 'Choose a key to edit' : 'Symbol keys'}>
        {rows.map((count, row) => (
          <div className="key-row" key={row} style={{'--stagger': row}}>
            {Array.from({length: count}, () => {
              const key = index++;
              const item = assigned(key);
              const label = item ? `${item.name} ${item.symbol}` : 'Empty';
              return (
                <button key={key} className={item ? 'key filled' : 'key'}
                  title={label} aria-label={`Key ${key + 1}: ${label}`}
                  aria-pressed={editing ? selected === key : undefined}
                  disabled={!ready || (!editing && !item)}
                  onPointerDown={event => { if (!editing) event.preventDefault(); }}
                  onClick={() => press(key, item)}>
                  {item?.symbol || (editing ? '+' : '·')}
                </button>
              );
            })}
          </div>
        ))}
      </div>
      <p className="status" role="status">{message || (editing
        ? selected === null ? 'Choose the key you want to assign.' : `Choose a symbol for key ${selected + 1}.`
        : filled ? 'Click in a text field, then press a symbol key.' : 'Select Edit keys to build your keyboard.')}</p>
      {editing && selected !== null && (
        <div className="library">
          <div className="filters">
            <input aria-label="Search symbols" placeholder="Search symbols, e.g. 1/2" value={query} onChange={event => setQuery(event.target.value)} />
            <select aria-label="Symbol category" value={category} onChange={event => setCategory(event.target.value)}>
              {['All symbols', ...categories].map(label => <option key={label}>{label}</option>)}
            </select>
          </div>
          <div className="results" aria-label="Matching symbols">
            {found.map(item => (
              <button key={item.symbol} title={item.name} aria-label={`${item.name} ${item.symbol}`}
                disabled={busy} onClick={() => assign(item)}>{item.symbol}</button>
            ))}
            {!found.length && <p>No matching symbols.</p>}
          </div>
          <form onSubmit={addCustom}>
            <input aria-label="Custom symbol" placeholder="Paste a custom symbol" value={custom}
              onChange={event => setCustom(event.target.value)} />
            <button disabled={!custom.trim() || busy} type="submit">Assign</button>
            {assigned(selected) && <button disabled={busy} type="button" onClick={() => assign(null)}>Clear key</button>}
          </form>
        </div>
      )}
    </section>
  );
}

const instanceKey = '__symbolKeyboardExtension';
if (globalThis[instanceKey]?.host.isConnected) {
  globalThis[instanceKey].toggle();
} else {
  const host = document.createElement('div');
  host.style.cssText = 'all: initial !important; position: fixed !important; inset: auto 0 0 auto !important; width: 0 !important; height: 0 !important; z-index: 2147483647 !important;';
  const shadow = host.attachShadow({mode: 'open'});
  const sheet = new CSSStyleSheet();
  sheet.replaceSync(styles);
  shadow.adoptedStyleSheets = [sheet];
  const mount = document.createElement('div');
  shadow.append(mount);
  document.documentElement.append(host);
  const root = createRoot(mount);
  const typing = createTypingTarget(host);
  let visible = false;
  function close() {
    visible = false;
    root.render(null);
  }
  function toggle() {
    if (visible) close();
    else {
      visible = true;
      root.render(<Keyboard close={close} typing={typing} />);
    }
  }
  globalThis[instanceKey] = {host, toggle};
  toggle();
}
