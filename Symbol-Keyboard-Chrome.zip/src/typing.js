const TEXT_INPUT = 'textarea, input:is([type=text], [type=search], [type=url], [type=tel], :not([type]))';

export function createTypingTarget(host) {
  let target = null;
  let range = null;

  function capture() {
    const active = document.activeElement;
    if (active === host) return;
    const editable = active?.isContentEditable
      ? active.closest('[contenteditable]:not([contenteditable=false])') || active
      : null;
    target = active?.matches(TEXT_INPUT) && !active.readOnly && !active.disabled
      ? active : editable;
    const selection = document.getSelection();
    range = target?.isContentEditable && selection?.rangeCount &&
      target.contains(selection.getRangeAt(0).commonAncestorContainer)
      ? selection.getRangeAt(0).cloneRange() : null;
  }

  function insert(symbol) {
    if (!target?.isConnected || target.readOnly || target.disabled ||
      (!target.matches(TEXT_INPUT) && !target.isContentEditable)) return false;
    if (target.isContentEditable && (!range || !target.contains(range.commonAncestorContainer))) return false;
    const field = target;
    const savedRange = range;
    const start = field.selectionStart;
    const end = field.selectionEnd;
    field.focus({preventScroll: true});
    if (field.isContentEditable) {
      const selection = document.getSelection();
      selection.removeAllRanges();
      selection.addRange(savedRange);
    } else {
      field.setSelectionRange(start, end);
      if (field.maxLength >= 0 && field.value.length - (end - start) + symbol.length > field.maxLength) return false;
    }
    // Chrome's editing command preserves undo and dispatches an input event.
    const inserted = document.execCommand('insertText', false, symbol);
    capture();
    return inserted;
  }

  document.addEventListener('focusin', capture, true);
  document.addEventListener('selectionchange', capture);
  capture();
  return {insert};
}
